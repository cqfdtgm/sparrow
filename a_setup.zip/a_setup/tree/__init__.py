﻿# -*- coding: utf-8 -*-
# $Header: D:\\RCS\\E\\dragonfly\\0_setup\\0_config\\__init__.py,v 1.0 2015-09-25 10:19:30+08 tgm Exp tgm $

import os

# import cfg

name = 'Tree表设置'

from .. import default as parent_default
class default(parent_default):
    _dirs = [os.path.dirname(__file__)] + parent_default._dirs
    _table = 'org'

    def __init__(self, *k, **kw):
        # kw.setdefault('_table', 'org')
        super(default, self).__init__(*k, **kw)
        #self._dic['_table_var_name'] = '_table_tree'
        #cherrypy.session.setdefault('_table_tree', 'org')
        #if '_table_tree' in kw:  # 通过右上角的"更改目标表"更改了表.
        #    cherrypy.session['_table_tree'] = kw.pop('_table_tree')
        #self._dic['_table'] = self._dic['table_form'] = cherrypy.session['_table_tree']
        self._dic['_real_table'] = self._dic['_table'] = kw.pop('_table', self._table)
        self._dic['table_kind'] = name
        self._dic['table_class'] = getattr(self.db, self._dic['_table'])

    def delete(self, _table, id):
        """为了做额外处理，拦截delete请求"""

        rec = self.db._select(_table, id=id)['rows'][0]
        print('debug: delete:', _table, id, rec)
        parentid = rec['parentid']
        # if rec['state'] == 'closed': # 如果有下级，不允许删除？
        #    return
        result = super(self.__class__, self).delete(_table, id)
        if result:  
            # 要将本节点作为上级的全部子节点全部删除！
            recs = self.db._select(_table, path=rec['path']+'.'+str(id)+'%')
            for rec in recs['rows']:
                self.db._delete(_table, rec['id'])
            # 如果删除成功，则要考察父节点下面是否还有子节点，以更改状态
            par_rec = self.db._select(_table, parentid=parentid)
            if not len(par_rec['rows']):
                self.db._update(_table, parentid, state='open')
        return result

    def tree(self, *k, **kw):
        """增加对于pagesize的参数，以例可以显示更多下级"""

        return super(self.__class__, self).tree(rows=100, *k, **kw)

    def insert(self, _table,  **kw):
        """为了保存path信息， 拦截Save请求并添加path字段。"""

        print ('k kw @ 0_setup\\tree', kw)
        kw['parentid'] = par = int(kw.pop('parentId')) # tree里上级是用parentid表示的，不同于treegrid.
        kw['state'] = 'open'
        # _table = kw['_table']
        if par==0:  # 是增加的根节点
            kw['path'] = '0'
            kw['level'] = 1
        else:
            rec = self.db._select(_table, id=par)['rows'][0]
            # 为便于保存url, 间隔符用/代替. 这个要和a_tree里的Tree里的join部分关联变动。
            kw['path'] = '%s.%s' % (rec['path'], par)    # 因增加记录以前，无法确定本记录的id，所以path其实是保存的到父记录的路径，加上父节点，才作为本记录的path；准确来说，本字段称为parent_path更恰当。
            # 再增加pathname字段，间隔符仍然是"."
            #kw['pathname'] = '%s.%s' % (rec.pathname, kw.get('text',''))
            kw['level'] = rec['level'] + 1
            del rec
        print ('k kw @ 0_setup\\tree left ', kw)
        result = super(default, self).insert(_table, **kw)
        print('result:', result, self.db._select(_table, id=par))
        if result:   # 增加成功的话，父节点的state要更改为closed.
            self.db._update(_table, id=par, state='closed')
            print('result:', result, self.db._select(_table, id=par))
        return result    

    def select(self, *k, **kw):
        """自定义Get, 为了处理q参数"""

        """
        if kw.pop('_log','') == 'true':
            kw['_table'] = self._dic['_table'] + '_log'
        else:
            kw['_table'] = self._dic.get('_real_table', self._dic['_table'])
            """
        if 'q' in kw:
            kwq = kw.pop('q')
            if kwq.encode().isalpha():  # 是字母, 则对config_tables按表名查找
                kw['name'] = '%'+ kwq + '%'
            else:
                kw['name_zh'] = '%' + kwq + '%'
        return super(default, self).select(*k, **kw)

__import__(__name__, {}, {}, [x.split('.')[0] for x in os.listdir(__name__.replace('.', os.sep))])

# $Log: __init__.py,v $
# Revision 1.0  2015-09-25 10:19:30+08  tgm
# Initial revision
#
